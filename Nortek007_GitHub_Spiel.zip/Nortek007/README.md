# Nortek007 – Geocaching-Schatzsuche

Ein kleines 2D-Browser-Spiel auf Deutsch für Handy und PC. Keine Installation, Anmeldung, GPS- oder Datenspeicherung erforderlich.

## Veröffentlichung mit GitHub Pages
1. Erstelle auf GitHub ein Repository namens `nortek007` und wähle **Public**.
2. Öffne das Repository und wähle **Add file → Upload files**.
3. Lade `index.html` hoch und bestätige mit **Commit changes**.
4. Öffne **Settings → Pages**.
5. Bei **Build and deployment** wähle **Deploy from a branch**.
6. Wähle Branch **main** und Ordner **/(root)**, dann **Save**.
7. Warte kurz. GitHub zeigt deine Spieladresse an. Sie sieht etwa so aus: `https://DEIN-BENUTZERNAME.github.io/nortek007/`.

## Spiel
Fünf Rätselstationen, Punktestand, Fortschritt und eine illustrative Karte. Die Karte zeigt keine echten GPS-Koordinaten.
